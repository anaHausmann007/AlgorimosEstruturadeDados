/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listaEstatica;

/**
 *
 * @author Master
 */
public class ListaEstatica {
    private int[] info;
    private int tamanho;
    
    public ListaEstatica(){
        int[] info = new int[10];
        this.tamanho = 0;
    }
    
    private void redimensionar(){
        int novaCapacidade=info.length+10;
        int[] infoRed = new int[novaCapacidade];
            for (int i = 0; i < tamanho; i++) {
            infoRed[i] = info[i];
            infoRed=info;
             }
          
    }
    
    public void inserir(int valor){
        if(tamanho==info.length){
            redimensionar();
        }
        
    info[tamanho] = valor;
        tamanho++;
    }
    
    public void exibir(){
        for (int i = 0; i < tamanho; i++) {
        System.out.print(info[i] + " | ");
        }
        System.out.println();
    }
    
//    public int buscar(int valor){
//        
//        return valor;
//        
//    }
//    
//    public void retirar(int valor){
//        
//    }
//    
//    public void liberar(){
//        
//    }
//    
//    public int obterElemento(int posicao){
//        int elemento;
//        return elemento;
//    }
//    
//    public boolean estaVazia(){
//        
//        return false;
//    }
//    
//    public int getTamanho(){
//        
//        return tamanho;
//    }
//    
//    public String toString(){
//        return info;
//    }
    
}
