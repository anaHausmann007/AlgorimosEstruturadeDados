/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listaEstatica;

/**
 *
 * @author Master
 */
public class App {
    public static void main(String[] args) {
        ListaEstatica arraylist= new ListaEstatica();
        arraylist.inserir(10);
        arraylist.inserir(2075898080);
        arraylist.inserir(3000);
        
        arraylist.exibir();
    }
}
