/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package listaEstatica;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ListaEstaticaTest {

    private ListaEstatica<String> arraySimples;

    // Método executado antes de cada teste
    @BeforeEach
    public void setUp() {
        arraySimples = new ListaEstatica<>(10); // Inicializa a lista com capacidade 10
    }

    @Test
    public void testInserir() {
        for (int i = 1; i <= 10; i++) {
            arraySimples.inserir(String.valueOf(i));
        }

        assertEquals(10, arraySimples.getTamanho());
        arraySimples.inserir("11");
        assertEquals(20, arraySimples.getCapacidade());

        assertEquals("1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11", arraySimples.toString());
    }

    @Test
    public void testBuscar() {
        arraySimples.inserir("5");
        arraySimples.inserir("joao");
        assertEquals(0, arraySimples.buscar("5"));
        assertEquals(1, arraySimples.buscar("joao"));
        assertEquals(-1, arraySimples.buscar("a")); // não existe
    }

    @Test
    public void testRetirar() {
        arraySimples.inserir("n");
        arraySimples.inserir("10.90");
        arraySimples.inserir("15");
        arraySimples.retirar("n");
        assertEquals(2, arraySimples.getTamanho());
        assertEquals("10.90, 15", arraySimples.toString());
    }

    @Test
    public void testLiberar() {
        arraySimples.inserir("5");
        arraySimples.inserir("10");
        arraySimples.liberar();
        assertEquals(0, arraySimples.getTamanho());
        assertTrue(arraySimples.estaVazia());
    }

    @Test
    public void testObterElemento() {
        arraySimples.inserir("5");
        arraySimples.inserir("10");

        assertEquals("5", arraySimples.obterElemento(0));
        assertEquals("10", arraySimples.obterElemento(1));

        assertThrows(IndexOutOfBoundsException.class, () -> arraySimples.obterElemento(3)); // Posição inválida
    }

    @Test
    public void testInverterComQuantidadePar() {
        arraySimples.inserir("5");
        arraySimples.inserir("10");
        arraySimples.inserir("15");
        arraySimples.inserir("20");
        arraySimples.inverter();
        assertEquals("20, 15, 10, 5", arraySimples.toString());
    }

    @Test
    public void testInverterComQuantidadeImpar() {
        arraySimples.inserir("5");
        arraySimples.inserir("10");
        arraySimples.inserir("15");
        arraySimples.inverter();
        assertEquals("15, 10, 5", arraySimples.toString());
    }

    @Test
    public void testInverterListaVazia() {
        arraySimples.inverter();
        assertEquals("", arraySimples.toString());
    }

    @Test
    public void testInverterListaComUmElemento() {
        arraySimples.inserir("100");
        arraySimples.inverter();
        assertEquals("100", arraySimples.toString());
    }
}