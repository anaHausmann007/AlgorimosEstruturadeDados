/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listaEstatica;

/**
 *
 * @author Master
 */
public class ListaEstatica<T> {
    private Object[] info;
    private int tamanho;
    
    public ListaEstatica(int capacidade) {
        info = new Object[capacidade];
        tamanho = 0;     }
    
   private void redimensionar() {
    int novaCapacidade = info.length + 10; 
    Object[] infoRed = new Object[novaCapacidade];

   
    for (int i = 0; i < tamanho; i++) {
        infoRed[i] = info[i];
    }

    // Atualiza a referência do array original para o novo array
    info = infoRed;
}

public void inserir(T valor) {
    if (tamanho == info.length) {
        redimensionar(); 
    }

    info[tamanho] = valor; 
    tamanho++; 
}
    
    public void exibir(){
        for (int i = 0; i < tamanho; i++) {
        System.out.print(info[i] + " | ");
        }
        System.out.println();
    }
    
    public int buscar(T valor){
          for (int i = 0; i < tamanho; i++) { 
            if (info[i].equals(valor)) { 
                return i; 
            }
        }
        return -1;
        
    }
    
    public void retirar(T valor){
    int posicao = buscar(valor);

    if (posicao != -1) { 
       
        for (int i = posicao; i < tamanho - 1; i++) {
            info[i] = info[i + 1];
            }

        tamanho--; 
        info[tamanho]=null;
        }
    }
    
    public void liberar(){
        this.info=new Object[10];
        this.tamanho=0;
    }
    
    public T obterElemento(int posicao) {
        if (posicao >= 0 && posicao < tamanho) {
             return (T) info[posicao]; 
        }else{ 
            throw new IndexOutOfBoundsException("Posição inválida");
        }
    }
    
    public boolean estaVazia(){
       return tamanho==0;
    }
    
    public int getTamanho(){
        
        return tamanho;
    }
    
      public int getCapacidade() {
        return info.length;
    }

    
     @Override
    public String toString() {
        String resultado = "";

        for (int i = 0; i < tamanho; i++) {
            resultado += info[i]; // adiciona o elemento atual a string
            if (i < tamanho - 1) { // adiciona uma virgula se não for o último elemento
                resultado += ", ";
            }
        }

        return resultado; 
    }
    
    public void inverter(){
    int esquerda=0;
    int direita=tamanho-1;
    int qteDeTrocas = tamanho/2;
    Object backup;
    
    while(qteDeTrocas>0){
        backup=info[esquerda];
        info[esquerda]=info[direita];
        info[direita]=backup;
        esquerda++;
        direita--;
        qteDeTrocas--;
 
        
    }
    }
              
    }
    

