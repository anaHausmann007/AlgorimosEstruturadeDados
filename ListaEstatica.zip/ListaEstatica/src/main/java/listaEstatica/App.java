/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listaEstatica;

/**
 *
 * @author Master
 */
public class App {
    public static void main(String[] args) {
        ListaEstatica<Integer> lista= new ListaEstatica<>(5);
            lista.inserir(2);
            lista.inserir(3);
            lista.inserir(4);
            lista.retirar(2);
            System.out.println(lista.toString());
  
        

    }
}
